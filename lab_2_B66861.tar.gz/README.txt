INTRUCTIONS TO RUN:

1. Una vez descargado este archivo comprimido en su directorio,
   ejecute la terminal en este mismo y digite: $ tar -xzf lab_2_B66861.tar.gz


2. Digite el comando $ make all para inicializar el programa.


3. Al finalizar el programa digite $ make clean para dehacerse del archivo compilado y el .tar.gz.


